{
    'name': "Tag email Department",
    'version': "1.0",
    'author': "Tag",
    'category': "Tools",
    'data': [
    'email.template.csv',
    'project_task.xml',
    'hr_department.xml',
    ],
    'demo': [],
    'depends': ['project','hr','web'],
    'installable': True,
}